module.exports = {
    user: 'user',
    department: 'department',
    profile: 'profile',
    user_profile: 'user_profile',
    vendor: 'vendor',
    purchase_status: 'purchase_status',
    purchase: 'purchase',
    purchase_item: 'purchase_item',
    goods_receipt: 'goods_receipt',
    goods_receipt_item: 'goods_receipt_item',
    approval: 'approval',
    approval_user: 'approval_user',
    purchase_record_type: 'purchase_record_type'
}